ActiveAdmin.register Attachment do

end
