$(function() {
    	$( "#home_tabs" ).tabs();
    	$( "#post_tabs" ).tabs();
    	tinyMCE.init({"selector":"textarea.admin_tinymce"});
});
