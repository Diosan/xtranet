ActiveAdmin.register TeamMember do

end
