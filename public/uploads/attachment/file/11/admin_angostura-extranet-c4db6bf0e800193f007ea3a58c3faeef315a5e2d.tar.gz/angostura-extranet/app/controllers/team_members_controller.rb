class TeamMembersController < InheritedResources::Base
end
