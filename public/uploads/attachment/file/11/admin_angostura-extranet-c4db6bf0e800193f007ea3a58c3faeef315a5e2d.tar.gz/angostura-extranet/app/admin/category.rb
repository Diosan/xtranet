ActiveAdmin.register Category do

end
