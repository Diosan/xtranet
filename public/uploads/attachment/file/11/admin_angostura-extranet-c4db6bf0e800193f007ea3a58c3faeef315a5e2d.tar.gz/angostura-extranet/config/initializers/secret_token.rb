# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Unified::Application.config.secret_key_base = 'c582c6bf7128948dbe8f5e50513ab7104b856edf70a3852ccd8a8d84f3f4f51b9e6f35fe62012239ff85e876f4093e33e4e55d9818ea9a1cadf041c1dfbd2d4d'
